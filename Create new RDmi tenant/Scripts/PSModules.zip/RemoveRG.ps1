﻿Param(
    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    [string] $SubscriptionId,
    [Parameter(Mandatory=$True)]
    [String] $Username,
    [Parameter(Mandatory=$True)]
    [string] $Password,
    [Parameter(Mandatory=$false)]
    [string] $publicIp,
    [Parameter(Mandatory=$false)]
    [string] $vNetName
 
)


$LoadModule=Get-Module -ListAvailable "Azure*"
if(!$LoadModule){
Install-PackageProvider NuGet -Force
Install-Module -Name AzureRM.profile -AllowClobber -Force
Install-Module -Name AzureRM.resources -AllowClobber -Force
}
Import-Module AzureRM.profile
Import-Module AzureRM.Compute

try{
$Securepass=ConvertTo-SecureString -String $Password -AsPlainText -Force
$Azurecred=New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList($Username, $Securepass)
$login=Login-AzureRmAccount -Credential $Azurecred -SubscriptionId $SubscriptionId

            Get-AzureRmVM | Where-Object {$_.name -eq $VMName}  | foreach {
                    $a=$_
                    [string]$OSDisk = @($_.StorageProfile.OSDisk.Name)
                                      
                        #Write-Warning -Message "Removing VM: $($_.Name)"
                        $_ | Remove-AzureRmVM -Force -Confirm:$false
                        

                        $_.NetworkProfile.NetworkInterfaces | ForEach-Object {
                            $NICName = Split-Path -Path $_.ID -leaf
                            Get-AzureRmNetworkInterface | Where-Object {$_.Name -eq $NICName} | Remove-AzureRmNetworkInterface -Force
                        }

                        # Support to remove managed disks
                        Get-AzureRmDisk | Where-Object {$_.Name -eq $OSDisk} | Remove-AzureRmDisk -Force
                        Get-AzureRmPublicIpAddress | Where-Object {$_.Name -eq $publicIp} | Remove-AzureRmPublicIpAddress -Force
                        Get-AzureRmVirtualNetwork | Where-Object {$_.Name -eq $vNetName} | Remove-AzureRmVirtualNetwork -Force
                       }
                       
                       }
                       catch{
                       Write-Error $_.Exception.Message
                       }